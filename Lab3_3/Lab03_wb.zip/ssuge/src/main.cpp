#include "stdafx.h"
#include <iostream>
#include "Application.h"


///The main function for executing the code
int main() 
{
	///Creates an instance of the application
	ssuge::Application mainApp = ssuge::Application();
	///Runs the application
	mainApp.run();

	return 0;
}